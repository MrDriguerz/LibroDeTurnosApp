package com.example.libroturnos

data class Tren(val numero: Int, val procedencia: String, val destino: String, val partida: Int, val llegada: Int, val turno: String)
{

}
