package com.example.libroturnos

data class Turno(val diagrama: String, val jornada: Int, val tomada: Int, val dejada: Int,val trenes: List<Tren>)
{

}
