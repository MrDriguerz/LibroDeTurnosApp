package com.example.libroturnos

enum class Jornada {

    lunes,
    martes,
    miercoles,
    jueves,
    viernes,
    sabado,
    domingo
}