package com.example.libroturnos

data class Diagrama(var numero: String, var franco: String)
